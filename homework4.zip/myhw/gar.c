#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <time.h>
#include <sys/types.h>

#include <stdlib.h>
#include <stdint.h>   /* Standard types */
#include <string.h>   /* String function definitions */
#include <unistd.h>   /* UNIX standard function definitions */
#include <fcntl.h>    /* File control definitions */
#include <errno.h>    /* Error number definitions */
#include <termios.h>  /* POSIX terminal control definitions */
#include <sys/ioctl.h>
#include <getopt.h>
#define sc scanf
#define pr printf
int main(){	

	// Method 1
	//Open communication with arduino	
	int portName = open("/dev/ttyUSB1", O_RDWR | O_NOCTTY | O_NDELAY);
	struct termios options;
	tcgetattr(portName, &options);
	cfsetispeed(&options, B9600);
	cfsetospeed(&options, B9600);
	options.c_cflag |= (CLOCAL | CREAD);
	tcsetattr(portName, TCSANOW, &options);
	//8 bit characters	
	options.c_cflag &= ~CSIZE; /* Mask the character size bits */
	options.c_cflag |= CS8;    /* Select 8 data bits */
	//No parity
	options.c_cflag &= ~PARENB;
	options.c_cflag &= ~CSTOPB;
	
	//Send Take Sample command to arduino
	char num[1000];
	
	

	//Read Hb answer
	unsigned char Hb[30];
	while(num[0]!='0')
	{
	pr("## WELCOME TO GTU ARDUINO LAB		##\n");
	pr("## STUDENT NAME: OZAN ARGIT ÖNÇEKEN	##\n");
	pr("## PLEASE SELECT FROM THE FOLLOWING 	##\n");
	pr("## MENU :				##\n");
	pr("(1) TURN ON LED ON ARDUINO\n");
	pr("(2) TURN OFF LED ON ARDUINO\n");
	pr("(3) FLASH ARDUINO LED 3 TIMES\n");
	pr("(4) SEND A NUMBER TO ARDUINO TO COMPUTE SQUARE BY ARDUINO\n");
	pr("(0) EXIT\nPLEASE SELECT:\n");
	sc("%s",num);
	if(num[0]=='1')
		{	write(portName,num,1);
			//read(portName,Hb,30);
			//pr("%s\n",Hb);
		}
	else if(num[0]=='2')
		{	write(portName,num,1);
			//read(portName,Hb,30);
			//pr("%s\n",Hb);
		}
	else if(num[0]=='3')
		{	write(portName,num,1);
			//read(portName,Hb,30);
			//pr("%s\n",Hb);
		}
	else if(num[0]=='4')
		{	
			sleep(1);
			//sleep for make sure that c and arduino connected

			write(portName,num,1);
			sleep(1);
			//int number;
			char number[9];
			sc("%s",number);
			//int *numhold;
			//numhold=&number;
			write(portName,number,9);
			read(portName,Hb,30);
			pr("%s\n",Hb);
		}
	
	}



	//Close communication
	close(portName);

	return 0;
}
