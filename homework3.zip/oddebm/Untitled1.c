#include<stdio.h>
#include<locale.h>//ismim türkçe karakter içeriyordu
#define pr printf//Kod yazarken çabukluk sağlamak için
#define sc scanf
void add();//geriye değer dönmeyecek işini fonksiyonda halledecek
void sub();
void multi();
void divide();
void nth();
void ave();
void max();
int main()
{
	int selecter = 1;
	setlocale(LC_ALL,"Turkish");//anladığım kadarıyla locale kütüphanesinin içinden neyi seçmek istediğimizi belirtiyoruz
	
	pr("%%%% WELCOME TO GTU CALCULATOR MACHINENE %%%%\n");
	pr("%%%% STUDENT NAME:OZAN ARGIT �N�EKEN %%%%\n");
	pr("%%%% PLEASE SELECT FROM THE FOLLOWING%%%%\n");
	pr("%%%% 		MENU		%%%%\n");
	pr("\n(1) ADD  TWO NUMBERS\n");
	pr("\n(2) SUBTRACT TWO NUMBERS\n");
	pr("\n(3) MULTIPLY TWO NUMBERS\n");
	pr("\n(4) DIVIDE TWO NUMBERS\n");
	pr("\n(5) TAKE THE NTH POWER OF A NUMBER\n");
	pr("\n(6) FIND AVERAGE OF NUMBERS INPUTTED\n");
	pr("\n(7) FIND THE MAXIMUM OF NUMBERS INPUTTED\n");
	pr("\n(0) EXIT\n");
	pr("\nPLEASE SELECT\n");
	
	while(selecter)
	{
	
	sc("%d",&selecter);

		if(selecter==1)//we don't need pointer here but � want to learn it
			add();
		else if(selecter==2)
			sub();
		else if(selecter==3)
			multi();
		else if (selecter==4)
			divide();
		else if(selecter==5)
			nth();
		else if(selecter==6)
			ave();
		else if(selecter==7)
			max();
		else if(selecter == 0)
			pr("You exit from the program\n");	
		else 
			pr("PLEASE ENTER VALID NUMBER");
		
		if(selecter)// if user �nputs 0 zero don't say PLEASE SELECT
			pr("\nPLEASE SELECT\n");
		
	}	
	
	

	return 0;
}

void add()
{
	float num1,num2;
	pr("PLEASE ENTER A NUMBER:");
	sc("%f",&num1);
	pr("PLEASE ENTER ANOTHER NUMBER:");
	sc("%f",&num2);
	pr("%f\n",num1+num2);
}
void sub()
{
	float num1,num2;
	pr("PLEASE ENTER A NUMBER:");
	sc("%f",&num1);
	pr("PLEASE ENTER ANOTHER NUMBER:");
	sc("%f",&num2);
	pr("%f\n",num1-num2);

}
void multi()
{
	float num1,num2;
	pr("PLEASE ENTER A NUMBER:");
	sc("%f",&num1);
	pr("PLEASE ENTER ANOTHER NUMBER:");
	sc("%f",&num2);
	pr("%f\n",num1*num2);

}
void divide()
{	
	float dividend,divider;
	pr("ENTER A NUMBER:");
	sc("%f",&dividend);
	pr("ENTER DIVIDER");
	sc("%f",&divider);
	pr("%f\n",dividend/divider);

}
void nth()
{	
	float num,pow,result;
	pr("ENTER A NUMBER:");
	sc("%f",&num);
	pr("ENTER THE POWER");
	sc("%f",&pow);
	result=1;
	int i;
	for(i=0;i<pow;i++)
		result*=num;
	pr("%f\n",result);

}
void ave()
{
	float string[999];
	pr("ENTER -1 FOR END GIVING NUMBER");
	int i;
	for(i=0;i<999;i++)
		{
			sc("%f",&string[i]);
			if(string[i]==-1)
				break;
		}
	float sum=0;
	int j;
		for(j=0;j<i;j++)
			{
				sum+=string[j];
			}
	sum/=i;

	pr("%f",sum);
}


void max()
{

	float string[9999];
	int i=0;
	pr("ENTER -1 FOR END GIVING NUMBER");
	/*	
	while (string[i-1]!=-1)
		{
			
			sc("%f",&string[i]);	
			i++;
		}
	*/
	for(i=0;i<999;i++)
		{
			sc("%f",&string[i]);
			if(string[i]==-1)
				break;
		}
	float max=0;
	i=0;
		while(string[i]!=-1)
			{
				if(string[i]>max)
					max=string[i];
			}
	pr("%f",max);
}
